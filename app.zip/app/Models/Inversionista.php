<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Inversionista extends Model
{
    use HasFactory;

    protected $table= 'inversionista';
    protected $primarykey='id';
}
